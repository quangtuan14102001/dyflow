"""Kiem tra cau hinh TRUOC khi job ton compute (tai video, Whisper, TTS).

OPENAI_API_KEY rong (copy tu .env.example) KHONG duoc che key that trong .env.
Chi fail khi da tim het cac file .env ma van khong co key.
Chi DYFLOW_ENV=dev moi duoc chay che do suy giam (test cuc bo).
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

from .utils import log

_DEV_ENVS = {"dev", "development", "local"}

MISSING_OPENAI = (
    "Thieu OPENAI_API_KEY (can khi dung OpenAI TTS hoac dich LLM full). "
    "Edge TTS + dich Google khong bat buoc key nay. "
    "Neu can: dien key rieng cua ban trong app / %LOCALAPPDATA%\\VideosCreator\\.env "
    "(khong dung key chung trong zip)."
)

MISSING_TTS_OPENAI = (
    "Chua co key OpenAI TTS cua ban. Job dung o pre-flight — "
    "dan key sk-... (platform.openai.com) trong app de dung tts-1 / HD / mini. "
    "Edge TTS khong can key nay."
)


def is_dev() -> bool:
    return (os.getenv("DYFLOW_ENV") or "").strip().lower() in _DEV_ENVS


def allow_degraded() -> bool:
    """Draft / skip-LLM / F0 chi khi DYFLOW_ENV=dev — khong bao gio tu fallback o production."""
    return is_dev()


def _desktop_env_path() -> Path:
    if sys.platform == "win32":
        base = Path(os.environ.get("LOCALAPPDATA") or (Path.home() / "AppData" / "Local"))
    elif sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support"
    else:
        base = Path(os.environ.get("XDG_DATA_HOME") or (Path.home() / ".local" / "share"))
    return base / "VideosCreator" / ".env"


def _env_files() -> list[Path]:
    """Moi file .env co the chua key. Chuoi rong khong tinh."""
    if (os.getenv("DYFLOW_IGNORE_DOTENV") or "").strip().lower() in ("1", "true", "yes"):
        return []
    out: list[Path] = []
    extra = (os.getenv("DYFLOW_ENV_FILE") or "").strip()
    if extra:
        out.append(Path(extra))
    pkg_root = Path(__file__).resolve().parents[1]
    out.append(pkg_root / ".env")
    if getattr(sys, "frozen", False):
        out.append(Path(sys.executable).resolve().parent / ".env")
        meipass = getattr(sys, "_MEIPASS", None)
        if meipass:
            out.append(Path(meipass) / ".env")
    out.append(Path.cwd() / ".env")
    out.append(_desktop_env_path())
    seen: set[str] = set()
    uniq: list[Path] = []
    for p in out:
        try:
            key = str(p.resolve())
        except OSError:
            key = str(p)
        if key in seen:
            continue
        seen.add(key)
        uniq.append(p)
    return uniq


def _read_dotenv_key(path: Path, name: str = "OPENAI_API_KEY") -> str:
    if not path.is_file():
        return ""
    try:
        from dotenv import dotenv_values

        return (dotenv_values(path).get(name) or "").strip()
    except Exception:  # noqa: BLE001
        return ""


def hydrate_openai_key() -> str:
    """Nap key that vao os.environ. OPENAI_API_KEY="" khong che file .env co sk-..."""
    current = (os.getenv("OPENAI_API_KEY") or "").strip()
    if current:
        return current
    for path in _env_files():
        key = _read_dotenv_key(path)
        if key:
            os.environ["OPENAI_API_KEY"] = key
            log.info("Nap OPENAI_API_KEY tu %s", path)
            return key
    return ""


def openai_key() -> str:
    """Key dich/LLM: uu tien key khach da dan (OPENAI_TTS_API_KEY), roi moi .env vendor."""
    try:
        from .user_openai import load_tts_key

        user = (load_tts_key() or "").strip()
        if user:
            return user
    except Exception:  # noqa: BLE001
        pass
    return hydrate_openai_key()


def alert_ops(kind: str, message: str, *, job_id: str = "") -> None:
    """Log [OPS] + Telegram admin. Khong hien thi cho end-user."""
    prefix = f"[OPS] {kind}"
    if job_id:
        prefix += f" job={job_id}"
    log.error("%s %s", prefix, message)
    try:
        from .web.notify import alert_ops as _tg

        _tg(kind, message, job_id=job_id)
    except Exception as e:  # noqa: BLE001
        log.debug("OPS telegram bo qua: %s", e)


def require_openai(*, kind: str = "draft_mode", job_id: str = "") -> str:
    """Tra OPENAI_API_KEY. Production: raise. Dev: alert va tra chuoi rong."""
    key = openai_key()
    if key:
        return key
    if allow_degraded():
        alert_ops(kind, MISSING_OPENAI, job_id=job_id)
        log.warning("DYFLOW_ENV=dev — tiep tuc o che do suy giam (%s)", kind)
        return ""
    alert_ops("preflight_fail" if kind == "preflight" else kind, MISSING_OPENAI, job_id=job_id)
    raise RuntimeError(MISSING_OPENAI)


def _required_keys(cfg: dict | None, job: dict | None) -> list[tuple[str, str]]:
    """(env_name, human_msg) cac key pipeline can cho job nay.

    Edge TTS + dich Google/polish (tuy chon): KHONG bat buoc OPENAI_API_KEY.
    Chi bat khi user chon OpenAI TTS hoac translate_llm=openai/deepseek/qwen (viet lai het).
    """
    keys: list[tuple[str, str]] = []
    vo: dict = {}
    if cfg:
        vo.update(cfg.get("voiceover") or {})
    if job:
        vo.update(job.get("voiceover") or {})
    engine = str(vo.get("tts_engine") or "edge").strip().lower()
    auto = {}
    if isinstance(vo.get("auto"), dict):
        auto.update(vo.get("auto") or {})
    if job and isinstance(job.get("auto"), dict):
        auto.update(job.get("auto") or {})
    translate_mode = str(auto.get("translate_llm") or "polish").strip().lower()

    if engine in ("openai", "tts-1", "tts-1-hd", "gpt-4o-mini-tts", "openai_tts"):
        keys.append(("OPENAI_API_KEY", MISSING_OPENAI))
        keys.append(("OPENAI_TTS_API_KEY", MISSING_TTS_OPENAI))
    elif engine in ("tvoice", "tvoiceai", "t_voice"):
        keys.append((
            "TVOICE_API_KEY",
            "Thiếu TVOICE_API_KEY (tts_engine=tvoice). Dán key sk_tvoice_... trong app.",
        ))
    elif translate_mode in ("openai", "full", "rewrite"):
        keys.append(("OPENAI_API_KEY", MISSING_OPENAI))
    elif translate_mode == "deepseek":
        keys.append((
            "DEEPSEEK_API_KEY",
            "Thieu DEEPSEEK_API_KEY (dich DeepSeek). Dan key trong app.",
        ))
    elif translate_mode == "qwen":
        keys.append((
            "QWEN_API_KEY",
            "Thieu QWEN_API_KEY / DASHSCOPE_API_KEY (dich Qwen). Dan key trong app.",
        ))
    return keys


def missing_keys(cfg: dict | None = None, job: dict | None = None) -> list[str]:
    hydrate_openai_key()
    out: list[str] = []
    for name, _msg in _required_keys(cfg, job):
        if name == "OPENAI_API_KEY":
            if not openai_key():
                out.append(name)
            continue
        if name == "OPENAI_TTS_API_KEY":
            from .user_openai import has_tts_key

            if not has_tts_key():
                out.append(name)
            continue
        if name == "TVOICE_API_KEY":
            from .user_tvoice import has_tvoice_key

            if not has_tvoice_key():
                out.append(name)
            continue
        if name == "DEEPSEEK_API_KEY":
            from .user_deepseek import has_deepseek_key

            if not has_deepseek_key():
                out.append(name)
            continue
        if name == "QWEN_API_KEY":
            from .user_qwen import has_qwen_key

            if not has_qwen_key():
                out.append(name)
            continue
        aliases = env_alias.get(name, (name,))
        if not any((os.getenv(a) or "").strip() for a in aliases):
            out.append(name)
    return out


def assert_job_ready(cfg: dict | None = None, job: dict | None = None) -> None:
    """Goi TRUOC download. Thieu key that (sau khi tim .env) -> RuntimeError ngay."""
    job_id = str((job or {}).get("id") or "")
    missing = missing_keys(cfg, job)
    if not missing:
        return
    if "OPENAI_TTS_API_KEY" in missing:
        msg = MISSING_TTS_OPENAI
    elif "OPENAI_API_KEY" in missing:
        msg = MISSING_OPENAI
    else:
        msg = (
            f"Thieu {', '.join(missing)}. Job da dung o buoc kiem tra cau hinh — "
            "chua tai video. Dat key trong .env."
        )
    if allow_degraded():
        alert_ops("draft_mode", msg, job_id=job_id)
        log.warning("DYFLOW_ENV=dev — cho phep chay job thieu key: %s", ", ".join(missing))
        return
    alert_ops("preflight_fail", msg, job_id=job_id)
    raise RuntimeError(msg)
